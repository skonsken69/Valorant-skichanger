1. start valorant

2. When ur in the lobby open the exe called valorant_skinchanger

3. Press on unlock all 

4. Go to ur inventory and now you have all skins 

ENJOY 